//
//  Gloss.h
//  Gloss
//
//  Created by Harlan Kellaway on 8/23/15.
//  Copyright © 2015 Harlan Kellaway. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Gloss.
FOUNDATION_EXPORT double GlossVersionNumber;

//! Project version string for Gloss.
FOUNDATION_EXPORT const unsigned char GlossVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Gloss/PublicHeader.h>


